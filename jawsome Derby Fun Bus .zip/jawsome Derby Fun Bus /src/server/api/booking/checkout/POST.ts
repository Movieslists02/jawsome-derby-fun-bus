﻿import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';


interface CheckoutBody {
 eventId: string;
 eventTitle: string;
 packageType: 'standard' | 'vip';
 quantity: number;
 customerName: string;
 customerEmail: string;
 customerPhone: string;
}


export default async function handler(req: Request, res: Response) {
 const stripeKey = getSecret('STRIPE_SECRET_KEY');


 if (!stripeKey) {
   // Stripe not yet configured — return a clear message
   return res.status(503).json({
     error: 'stripe_not_configured',
     message: 'Payment processing is not yet configured. Please add your Stripe API keys to enable bookings.',
   });
 }


 const { eventId, eventTitle, packageType, quantity, customerName, customerEmail, customerPhone } =
   req.body as CheckoutBody;


 if (!eventId || !eventTitle || !packageType || !quantity || !customerName || !customerEmail) {
   return res.status(400).json({ error: 'Missing required fields' });
 }


 try {
   // Dynamic import so the module only loads when Stripe is configured
   const Stripe = (await import('stripe')).default;
   const stripe = new Stripe(stripeKey as string, { apiVersion: '2026-04-22.dahlia' });


   const unitAmount = packageType === 'vip' ? 29500 : 19500; // cents
   const packageLabel = packageType === 'vip' ? 'VIP Package' : 'Standard Package';


   const origin = `${req.protocol}://${req.get('host')}`;


   const session = await stripe.checkout.sessions.create({
     payment_method_types: ['card'],
     line_items: [
       {
         price_data: {
           currency: 'usd',
           product_data: {
             name: `${eventTitle} — ${packageLabel}`,
             description: `Jawsome Racing Fun Bus Experience • Round trip transportation, food, drinks & racetrack admission`,
             images: [],
           },
           unit_amount: unitAmount,
         },
         quantity,
       },
     ],
     mode: 'payment',
     customer_email: customerEmail,
     metadata: {
       eventId,
       eventTitle,
       packageType,
       customerName,
       customerPhone,
     },
     success_url: `${origin}/booking-success?session_id={CHECKOUT_SESSION_ID}`,
     cancel_url: `${origin}/book?cancelled=true`,
   });


   res.json({ url: session.url });
 } catch (err) {
   console.error('stripe.checkout.error', err);
   res.status(500).json({ error: 'Failed to create checkout session', message: String(err) });
 }
}