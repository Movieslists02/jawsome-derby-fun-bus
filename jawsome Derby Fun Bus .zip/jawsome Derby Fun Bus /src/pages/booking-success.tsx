﻿import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { CheckCircle, ArrowRight, Calendar, Mail } from 'lucide-react';


interface BookingDetails {
 customerEmail: string;
 metadata: {
   eventTitle: string;
   packageType: string;
   customerName: string;
 };
 amountTotal: number;
}


export default function BookingSuccessPage() {
 const [searchParams] = useSearchParams();
 const sessionId = searchParams.get('session_id');
 const [details, setDetails] = useState<BookingDetails | null>(null);
 const [loading, setLoading] = useState(true);


 useEffect(() => {
   if (!sessionId) { setLoading(false); return; }
   fetch(`/api/booking/verify?session_id=${sessionId}`)
     .then((r) => r.json())
     .then((data) => {
       if (data.status === 'paid') setDetails(data);
       setLoading(false);
     })
     .catch(() => setLoading(false));
 }, [sessionId]);


 return (
   <>
     <Helmet>
       <title>Booking Confirmed — Jawsome Racing</title>
       <meta name="robots" content="noindex" />
     </Helmet>


     <div className="min-h-screen bg-background flex items-center justify-center px-4 py-20">
       <div className="max-w-lg w-full text-center">
         <motion.div
           initial={{ scale: 0.5, opacity: 0 }}
           animate={{ scale: 1, opacity: 1 }}
           transition={{ type: 'spring', duration: 0.6 }}
           className="flex justify-center mb-6"
         >
           <div className="w-20 h-20 rounded-full bg-primary/10 border-2 border-primary flex items-center justify-center">
             <CheckCircle size={40} className="text-primary" />
           </div>
         </motion.div>


         <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ delay: 0.3, duration: 0.5 }}
           className="flex flex-col gap-4"
         >
           <h1 className="font-heading text-4xl md:text-5xl text-foreground">You're In!</h1>


           {loading ? (
             <p className="text-muted-foreground">Loading your booking details...</p>
           ) : details ? (
             <div className="flex flex-col gap-4">
               <p className="text-muted-foreground text-lg">
                 Your spot on the Jawsome Racing Fun Bus is confirmed,{' '}
                 <span className="text-foreground font-semibold">{details.metadata.customerName}</span>.
               </p>


               <div className="bg-card border border-border rounded-lg divide-y divide-border text-left mt-2">
                 <div className="p-4 flex items-center gap-3">
                   <Calendar size={16} className="text-primary shrink-0" />
                   <div>
                     <p className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Event</p>
                     <p className="text-sm text-foreground font-semibold">{details.metadata.eventTitle}</p>
                     <p className="text-xs text-primary capitalize">{details.metadata.packageType} Package</p>
                   </div>
                 </div>
                 <div className="p-4 flex items-center gap-3">
                   <Mail size={16} className="text-primary shrink-0" />
                   <div>
                     <p className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Confirmation sent to</p>
                     <p className="text-sm text-foreground">{details.customerEmail}</p>
                   </div>
                 </div>
                 <div className="p-4 flex items-center justify-between">
                   <p className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Amount Paid</p>
                   <p className="font-heading text-2xl text-primary">${((details.amountTotal ?? 0) / 100).toFixed(0)}</p>
                 </div>
               </div>
             </div>
           ) : (
             <p className="text-muted-foreground text-lg">
               Your booking is confirmed! Check your email for details.
             </p>
           )}


           <p className="text-sm text-muted-foreground mt-2">
             We'll be in touch with pickup details and race day info closer to the event. Get ready for an incredible day at Saratoga.
           </p>


           <div className="flex flex-col sm:flex-row gap-3 justify-center mt-4">
             <Link
               to="/events"
               className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-border text-muted-foreground hover:text-primary hover:border-primary text-sm font-bold uppercase tracking-wider rounded transition-all"
             >
               View All Events
             </Link>
             <Link
               to="/"
               className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-black text-sm font-bold uppercase tracking-wider rounded transition-all hover:brightness-110"
             >
               Back to Home <ArrowRight size={14} />
             </Link>
           </div>
         </motion.div>
       </div>
     </div>
   </>
 );
}