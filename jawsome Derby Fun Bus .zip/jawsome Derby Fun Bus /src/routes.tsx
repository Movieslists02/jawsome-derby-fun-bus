﻿import { RouteObject } from 'react-router-dom';
import { lazy } from 'react';
import HomePage from './pages/index';
import ProdNotFoundPage from './pages/_404';


const NotFoundPage = import.meta.env.DEV
 ? lazy(() => import('../dev-tools/src/PageNotFound'))
 : ProdNotFoundPage;


const BookPage = lazy(() => import('./pages/book'));
const BookingSuccessPage = lazy(() => import('./pages/booking-success'));
const EventsPage = lazy(() => import('./pages/events'));
const MerchPage = lazy(() => import('./pages/merch'));
const AboutPage = lazy(() => import('./pages/about'));
const ContactPage = lazy(() => import('./pages/contact'));


export const routes: RouteObject[] = [
 { path: '/', element: <HomePage /> },
 { path: '/book', element: <BookPage /> },
 { path: '/booking-success', element: <BookingSuccessPage /> },
 { path: '/events', element: <EventsPage /> },
 { path: '/merch', element: <MerchPage /> },
 { path: '/about', element: <AboutPage /> },
 { path: '/contact', element: <ContactPage /> },
 { path: '*', element: <NotFoundPage /> },
];


export type Path = '/' | '/book' | '/booking-success' | '/events' | '/merch' | '/about' | '/contact';
export type Params = Record<string, string | undefined>;